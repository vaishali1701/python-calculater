
# 🧮 Python Calculator

A simple **GUI Calculator** built with Python and Tkinter.  
It performs basic arithmetic operations like addition, subtraction, multiplication, and division.

## 📸 Demo
![Calculator Screenshot](screenshots/demo.png)

## 🚀 Features
- GUI-based (Tkinter)
- Basic arithmetic operations
- Clear button
- Error handling

## 🛠️ Technologies Used
- Python 3
- Tkinter (Python GUI Library)

## ▶️ How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/python-calculator.git
   cd python-calculator
   ```
2. Run the program:
   ```bash
   python calculator.py
   ```

## 📌 Future Improvements
- Add scientific features (square root, power, history)
- Add dark mode
- Improve UI design
