
import tkinter as tk

def on_click(event):
    text = event.widget.cget("text")
    if text == "=":
        try:
            result = eval(str(entry.get()))
            entry_var.set(result)
        except Exception:
            entry_var.set("Error")
    elif text == "C":
        entry_var.set("")
    else:
        entry_var.set(entry_var.get() + text)

# Main window
root = tk.Tk()
root.title("Simple Calculator")

entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=("Arial", 20), justify="right")
entry.grid(row=0, column=0, columnspan=4, padx=8, pady=8, sticky="nsew")

# Configure grid for responsive layout
for i in range(5):
    root.grid_rowconfigure(i, weight=1)
for j in range(4):
    root.grid_columnconfigure(j, weight=1)

# Buttons layout
buttons = [
    ["7", "8", "9", "+"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "*"],
    ["C", "0", "=", "/"]
]

for i in range(4):
    for j in range(4):
        btn = tk.Button(root, text=buttons[i][j], font=("Arial", 18), height=2, width=5)
        btn.grid(row=i+1, column=j, padx=4, pady=4, sticky="nsew")
        btn.bind("<Button-1>", on_click)

root.mainloop()
